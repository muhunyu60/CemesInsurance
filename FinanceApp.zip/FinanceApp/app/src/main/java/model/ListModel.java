package model;

/**
 * Created by wolfsoft4 on 24/9/18.
 */

public class ListModel {
    String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ListModel(String title) {
        this.title = title;
    }
}
