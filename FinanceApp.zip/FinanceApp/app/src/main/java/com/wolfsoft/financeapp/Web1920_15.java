package com.wolfsoft.financeapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Web1920_15 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web1920_15);
    }
}
